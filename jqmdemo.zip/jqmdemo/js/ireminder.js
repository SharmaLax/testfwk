'use strict'
  var username = "";
  var password = "";
  var DEMODB = null;
  var user = "";
  var alertTypes = ["Quiet", "Vibrate", "Ring", "Ring+Vibrate"];
  initDatabase();

  function pageControler(pagename){

    switch(pagename){

      case "reminders":
        loadReminderList();
        $( ":mobile-pagecontainer" ).pagecontainer( "change", "#reminders", { transition: "slideup"  } );
        break;
      default:
          logout();
          $( ":mobile-pagecontainer" ).pagecontainer( "change", "#login", { transition: "slideup" } );
    }

  }
  function doLogin() {
    username = $("#username").val();
    password = $("#password").val();
    if (username == "") {
      $("#message").text("Missing username.")
    } else {
      isUserExists(username, password);
    }

  }

  function logout() {
    $("#username").val("");
    $("#password").val("");
    user = null;
  }




  function nullDataHandler() {

  }

  function errorHandler(err) {

  }

  function registerNewUser() {

    var username = $("#usernamereg").val();
    var password = $("#passwordreg").val();
    var rppassword = $("#rppassword").val();
    var email = $("#email").val();
    var agree = $("#agree").val();

    if (username == "") {
      $("#messagereg").text("Missing username.")
    }
    if (email == "") {
      $("#messagereg").text("Missing email.")
    }
    if (password == "") {
      $("#messagereg").text("Missing password.")
    }
    if (password != rppassword) {
      $("#messagereg").text("passwords are not the same")
    }
    if (agree != "on") {
      $("#messagereg").text("Please accept the agreement")
    }
    registerUser(username, email, password, $("#messagereg"));
  }


  function addReminderHandler(transaction, results) {
    if (results.rowaffected > 0) {

    }
    pageControler("reminders");
  }

  function addReminder() {
    var username = user.username;
    var title = $("#eventname").val();
    var time = $("#datetime-l").val();
    var atype = $("#rtype").val();
    DEMODB.transaction(
      function(transaction) {
        transaction.executeSql("INSERT INTO REMINDERS( username, title, time , alarmtype) VALUES (?, ?, ? , ?)", [username, title, time, atype], addReminderHandler, errorHandler);
      }
    );
  }
  function delReminderHandler(transaction, results) {
    if (results.rowaffected > 0) {

    }

    pageControler("reminders");
  }

  function deleteReminder(reminderID){
    DEMODB.transaction(
      function(transaction) {
        transaction.executeSql("DELETE FROM REMINDERS where id=?",[reminderID], delReminderHandler, errorHandler);
      }
    );
  }
  function createUserHandler(transaction, results) {
    if (results.rowaffected > 0) {
      $("#messagereg").text("User Created Succesfuly");
      pageControler("login");
    }
  }

  function registerUser(username, email, password, msgObj) {
    DEMODB.transaction(
      function(transaction) {
        transaction.executeSql("INSERT INTO USERS( username, password, email) VALUES (?, ?, ?)", [username, password, email], createUserHandler, errorHandler);
      }
    );
  }

  function usersExistsHandler(transaction, results) {

    // Handle the results
    if (results.rows.length > 0) {
      var row = results.rows.item(0);
      user = new Object();
      user.username = row['username'];
      user.password = row['password'];
      user.email = row['email'];
      pageControler("reminders");

    } else {
      user = null;
      $("#message").text("invalid username or wrong password.")
    }

  }

  function isUserExists(username, password) {
    DEMODB.transaction(
      function(transaction) {
        transaction.executeSql("SELECT * FROM USERS where username=? and password=?", [username, password],
          usersExistsHandler, errorHandler);
      }
    );
  }

  function prePopulate() {
    DEMODB.transaction(
      function(transaction) {
        //Optional Starter Data when page is initialized
        var data = ['1', 'admin', 'iamadmin', 'admin@remindme.com'];
        transaction.executeSql("INSERT INTO USERS(id, username, password, email) VALUES (?, ?, ?, ?)", [data[0], data[1], data[2], data[3]]);
      }
    );
    DEMODB.transaction(
      function(transaction) {
        //Optional Starter Data when page is initialized
        var data = ['1', 'admin', 'CATJS Dev meetup', "2014-06-11T13:59", 3];
        transaction.executeSql("INSERT INTO REMINDERS(id, username, title, time , alarmtype) VALUES (?, ?, ?, ? ,?)", [data[0], data[1], data[2], data[3], data[4]]);
      }
    );
  }

  function createTables() {
    DEMODB.transaction(
      function(transaction) {
        transaction.executeSql('CREATE TABLE IF NOT EXISTS USERS(id INTEGER NOT NULL PRIMARY KEY ASC, username TEXT NOT NULL,password TEXT NOT NULL, email TEXT NOT NULL);', [], nullDataHandler, errorHandler);
        transaction.executeSql('CREATE TABLE IF NOT EXISTS REMINDERS(id INTEGER NOT NULL PRIMARY KEY ASC, username TEXT NOT NULL,title TEXT NOT NULL, time datetime NOT NULL , alarmtype INTEGER NOT NULL);', [], nullDataHandler, errorHandler);
      }
    );
    prePopulate();
  }

  function initDatabase() {
    try {
      if (!window.openDatabase) {
        alert('Databases are not supported in this browser.');
      } else {
        var shortName = 'CATJSDEMODB';
        var version = '1.0';
        var displayName = 'CATJSDEMO Database';
        var maxSize = 100000; //  bytes
        DEMODB = openDatabase(shortName, version, displayName, maxSize);
        createTables();

      }
    } catch (e) {

      if (e == 2) {
        // Version number mismatch.
        console.log("Invalid database version.");
      } else {
        console.log("Unknown error " + e + ".");
      }
      return;
    }
  }


  function loadRemindersHandler(transaction, results) {

    $("#remindlist").empty();
    var item = Handlebars.compile('<li id=\'ID{{id}}\' caption=\'{{title}}\'><a href=\'#reminders\' ><p><h3>{{title}}</h3><p><p><strong>{{alert}}</strong><p class=\'ui-li-aside\'><strong>'
       + '{{date}}</strong></p></a><a id=\'DL{{id}}\' href=\'#\' class=\'delete\'>delete</a></li>');

    for (var i = 0; i < results.rows.length; i++) {
      var row = results.rows.item(i);
      var d = new Date(row['time']);
      var itemhtml = item({id : row['id'] , title : row['title'], alert : alertTypes[row['alarmtype']] ,date:d.toDateString()}  );
      $('#remindlist').append(itemhtml);
    }

    $('.delete').on('click',function(event) {
          var item_id = String(this.id).substring(2);
          console.log(item_id); // id of clicked li by directly accessing DOMElement property
          deleteReminder(item_id);
      });
    $("#remindlist").listview("refresh");
  }
  function loadReminderList(){
    if (user == null)
      return false;
    DEMODB.transaction(
      function(transaction) {
        transaction.executeSql("SELECT * FROM REMINDERS where username=?", [user.username],
          loadRemindersHandler, errorHandler);
      }
    );
  }


  $(document).on("pageshow", "#reminders",
    function(event) {
      loadReminderList();
    });
