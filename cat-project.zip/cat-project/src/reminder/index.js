_cat.core.define("reminder.index.html.loginold", function() {

  var pkgName = "reminder.index.html.loginold";

  return {

    /**
     * Init functionality for scrap reminder.index.html.loginold
     *
     * @param content CAT Context object
     */
    init: function(context) {

    }
  };

}());
_cat.core.define("reminder.index.html.login", function() {

  var pkgName = "reminder.index.html.login";

  return {

    /**
     * Init functionality for scrap reminder.index.html.login
     *
     * @param content CAT Context object
     */
    init: function(context) {

    }
  };

}());
_cat.core.define("reminder.index.html.add_reminder", function() {

  var pkgName = "reminder.index.html.add_reminder";

  return {

    /**
     * Init functionality for scrap reminder.index.html.add_reminder
     *
     * @param content CAT Context object
     */
    init: function(context) {

    }
  };

}());
_cat.core.define("reminder.index.html.delete_reminder", function() {

  var pkgName = "reminder.index.html.delete_reminder";

  return {

    /**
     * Init functionality for scrap reminder.index.html.delete_reminder
     *
     * @param content CAT Context object
     */
    init: function(context) {

    }
  };

}());
_cat.core.define("reminder.index.html.logout", function() {

  var pkgName = "reminder.index.html.logout";

  return {

    /**
     * Init functionality for scrap reminder.index.html.logout
     *
     * @param content CAT Context object
     */
    init: function(context) {

    }
  };

}());