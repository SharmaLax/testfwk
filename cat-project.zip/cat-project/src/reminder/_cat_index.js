_cat.core.declare('reminder.index.html.loginold$$cat', {
  scrap: {
    "name": ["loginold"],
    "embed": ["true"],
    "jqm": ["setText(\"#username\", \"admin\");", "setText(\"#password\", \"iamadmin\");", "clickButton(\"#loginbtn\");"],
    "file": "/Users/eli.mordechaihp.com/Documents/cat-project/target/reminder/index.html",
    "scrapinfo": {
      "start": {
        "line": 33,
        "col": 0
      },
      "end": {
        "line": 39,
        "col": 4
      }
    },
    "commentinfo": {
      "start": {
        "line": 32,
        "col": 0
      },
      "end": {
        "line": 40,
        "col": 3
      }
    },
    "single": {
      "name": true,
      "embed": true,
      "jqm": false,
      "file": true,
      "scrapinfo": true,
      "commentinfo": true,
      "single": true,
      "singleton": true,
      "arguments": true,
      "context": false,
      "auto": true,
      "injectcode": true,
      "id": true,
      "$type": true,
      "numCommands": true
    },
    "singleton": {
      "name": -1,
      "embed": -1,
      "jqm": -1,
      "file": -1,
      "scrapinfo": -1,
      "commentinfo": -1,
      "single": -1,
      "singleton": -1,
      "arguments": -1,
      "context": 1,
      "auto": -1,
      "injectcode": -1,
      "id": -1,
      "$type": -1,
      "numCommands": -1
    },
    "arguments": ["thi$"],
    "context": ["thi$"],
    "auto": true,
    "injectcode": false,
    "id": "scrap_16930807-a8ba-ad7f-0491-a567ac76203a",
    "$type": "html",
    "numCommands": 4,
    "pkgName": "reminder.index.html.loginold"
  }
}, 'scrap');
_cat.core.define("reminder.index.html.loginold$$cat", function(thi$) {

  var pkgName = "reminder.index.html.loginold$$cat",
    _argsrefs = arguments,
    _argsnames = "thi$",
    _args = {},
    _ipkg = _cat.core.getVar(pkgName),
    _counter = 0;

  if (_args) {
    _argsnames = _argsnames.split(",");
    _argsnames.forEach(function(arg) {
      _args[arg] = _argsrefs[_counter];
      _counter++;
    });
  }

  /* test content in here */
  _cat.core.clientmanager.delayManager(["_cat.core.ui.setContent({style: 'color:#0080FF', header: 'loginold', desc: 'setText(\"#username\", \"admin\");,setText(\"#password\", \"iamadmin\");,clickButton(\"#loginbtn\");',tips: ''});"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.setText(\"#username\", \"admin\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.setText(\"#password\", \"iamadmin\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.clickButton(\"#loginbtn\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
});
_cat.core.declare('reminder.index.html.login$$cat', {
  scrap: {
    "name": ["login"],
    "embed": ["true"],
    "jqm": ["setText(\"#username\", \"admin\");", "setText(\"#password\", \"iamadmin\");", "clickButton(\"#loginbtn\");"],
    "assert": ["ok($.mobile.activePage.attr(\"id\")==\"reminders\",\"login failed\");"],
    "file": "/Users/eli.mordechaihp.com/Documents/cat-project/target/reminder/index.html",
    "scrapinfo": {
      "start": {
        "line": 43,
        "col": 0
      },
      "end": {
        "line": 50,
        "col": 4
      }
    },
    "commentinfo": {
      "start": {
        "line": 42,
        "col": 0
      },
      "end": {
        "line": 51,
        "col": 3
      }
    },
    "single": {
      "name": true,
      "embed": true,
      "jqm": false,
      "assert": false,
      "file": true,
      "scrapinfo": true,
      "commentinfo": true,
      "single": true,
      "singleton": true,
      "arguments": true,
      "context": false,
      "auto": true,
      "injectcode": true,
      "id": true,
      "$type": true,
      "numCommands": true
    },
    "singleton": {
      "name": -1,
      "embed": -1,
      "jqm": -1,
      "assert": -1,
      "file": -1,
      "scrapinfo": -1,
      "commentinfo": -1,
      "single": -1,
      "singleton": -1,
      "arguments": -1,
      "context": 1,
      "auto": -1,
      "injectcode": -1,
      "id": -1,
      "$type": -1,
      "numCommands": -1
    },
    "arguments": ["thi$"],
    "context": ["thi$"],
    "auto": true,
    "injectcode": false,
    "id": "scrap_4687e14d-6c3e-a58d-61c5-c6aceb60176b",
    "$type": "html",
    "numCommands": 5,
    "pkgName": "reminder.index.html.login"
  }
}, 'scrap');
_cat.core.define("reminder.index.html.login$$cat", function(thi$) {

  var pkgName = "reminder.index.html.login$$cat",
    _argsrefs = arguments,
    _argsnames = "thi$",
    _args = {},
    _ipkg = _cat.core.getVar(pkgName),
    _counter = 0;

  if (_args) {
    _argsnames = _argsnames.split(",");
    _argsnames.forEach(function(arg) {
      _args[arg] = _argsrefs[_counter];
      _counter++;
    });
  }

  /* test content in here */
  _cat.core.clientmanager.delayManager(["_cat.core.ui.setContent({style: 'color:#0080FF', header: 'login', desc: 'setText(\"#username\", \"admin\");,setText(\"#password\", \"iamadmin\");,clickButton(\"#loginbtn\");',tips: ''});"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.setText(\"#username\", \"admin\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.setText(\"#password\", \"iamadmin\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.clickButton(\"#loginbtn\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.utils.chai.assert(context);"], {
    'code': ["assert", "ok($.mobile.activePage.attr(\"id\")==\"reminders\",\"login failed\")\n"].join("."),
    'fail': true,
    scrap: _ipkg.scrap,
    args: _args
  });
});
_cat.core.declare('reminder.index.html.add_reminder$$cat', {
  scrap: {
    "name": ["add_reminder"],
    "embed": ["true"],
    "jqm": ["clickButton(\"#createreminderbtn\");", "setText(\"#eventname\", \"Apple iPhone Big Announcement\");", "setText(\"#datetime-l\", \"2014-09-09T10:00\");", "selectMenu(\"#rtype\",3);", "clickButton(\"#addreminderbtn\");"],
    "assert": ["ok($(\"#remindlist li[caption=\\\"Apple iPhone Big Announcement\\\"] a[title=\\\"delete\\\"]\").size()==1,\"create new reminder failed\");"],
    "file": "/Users/eli.mordechaihp.com/Documents/cat-project/target/reminder/index.html",
    "scrapinfo": {
      "start": {
        "line": 54,
        "col": 0
      },
      "end": {
        "line": 63,
        "col": 2
      }
    },
    "commentinfo": {
      "start": {
        "line": 53,
        "col": 0
      },
      "end": {
        "line": 64,
        "col": 3
      }
    },
    "single": {
      "name": true,
      "embed": true,
      "jqm": false,
      "assert": false,
      "file": true,
      "scrapinfo": true,
      "commentinfo": true,
      "single": true,
      "singleton": true,
      "arguments": true,
      "context": false,
      "auto": true,
      "injectcode": true,
      "id": true,
      "$type": true,
      "numCommands": true
    },
    "singleton": {
      "name": -1,
      "embed": -1,
      "jqm": -1,
      "assert": -1,
      "file": -1,
      "scrapinfo": -1,
      "commentinfo": -1,
      "single": -1,
      "singleton": -1,
      "arguments": -1,
      "context": 1,
      "auto": -1,
      "injectcode": -1,
      "id": -1,
      "$type": -1,
      "numCommands": -1
    },
    "arguments": ["thi$"],
    "context": ["thi$"],
    "auto": true,
    "injectcode": false,
    "id": "scrap_d45bee56-6e44-d018-f7dd-d99fba23467f",
    "$type": "html",
    "numCommands": 7,
    "pkgName": "reminder.index.html.add_reminder"
  }
}, 'scrap');
_cat.core.define("reminder.index.html.add_reminder$$cat", function(thi$) {

  var pkgName = "reminder.index.html.add_reminder$$cat",
    _argsrefs = arguments,
    _argsnames = "thi$",
    _args = {},
    _ipkg = _cat.core.getVar(pkgName),
    _counter = 0;

  if (_args) {
    _argsnames = _argsnames.split(",");
    _argsnames.forEach(function(arg) {
      _args[arg] = _argsrefs[_counter];
      _counter++;
    });
  }

  /* test content in here */
  _cat.core.clientmanager.delayManager(["_cat.core.ui.setContent({style: 'color:#0080FF', header: 'add_reminder', desc: 'clickButton(\"#createreminderbtn\");,setText(\"#eventname\", \"Apple iPhone Big Announcement\");,setText(\"#datetime-l\", \"2014-09-09T10:00\");,selectMenu(\"#rtype\",3);,clickButton(\"#addreminderbtn\");',tips: ''});"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.clickButton(\"#createreminderbtn\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.setText(\"#eventname\", \"Apple iPhone Big Announcement\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.setText(\"#datetime-l\", \"2014-09-09T10:00\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.selectMenu(\"#rtype\",3);"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.clickButton(\"#addreminderbtn\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.utils.chai.assert(context);"], {
    'code': ["assert", "ok($('#remindlist li[caption=\"Apple iPhone Big Announcement\"] a[title=\"delete\"]').size()==1,\"create new reminder failed\")\n"].join("."),
    'fail': true,
    scrap: _ipkg.scrap,
    args: _args
  });
});
_cat.core.declare('reminder.index.html.delete_reminder$$cat', {
  scrap: {
    "name": ["delete_reminder"],
    "embed": ["true"],
    "jqm": ["click($(\"#remindlist li[caption=\\\"Apple iPhone Big Announcement\\\"] a[title=\\\"delete\\\"]\"));"],
    "assert": ["ok($(\"#remindlist li[caption=\\\"Apple iPhone Big Announcement\\\"] a[title=\\\"delete\\\"]\").size() == 0,\"delete reminder failed\");"],
    "file": "/Users/eli.mordechaihp.com/Documents/cat-project/target/reminder/index.html",
    "scrapinfo": {
      "start": {
        "line": 67,
        "col": 0
      },
      "end": {
        "line": 72,
        "col": 2
      }
    },
    "commentinfo": {
      "start": {
        "line": 66,
        "col": 0
      },
      "end": {
        "line": 73,
        "col": 3
      }
    },
    "single": {
      "name": true,
      "embed": true,
      "jqm": false,
      "assert": false,
      "file": true,
      "scrapinfo": true,
      "commentinfo": true,
      "single": true,
      "singleton": true,
      "arguments": true,
      "context": false,
      "auto": true,
      "injectcode": true,
      "id": true,
      "$type": true,
      "numCommands": true
    },
    "singleton": {
      "name": -1,
      "embed": -1,
      "jqm": -1,
      "assert": -1,
      "file": -1,
      "scrapinfo": -1,
      "commentinfo": -1,
      "single": -1,
      "singleton": -1,
      "arguments": -1,
      "context": 1,
      "auto": -1,
      "injectcode": -1,
      "id": -1,
      "$type": -1,
      "numCommands": -1
    },
    "arguments": ["thi$"],
    "context": ["thi$"],
    "auto": true,
    "injectcode": false,
    "id": "scrap_661bef0b-b544-8921-4049-5d358ea31677",
    "$type": "html",
    "numCommands": 3,
    "pkgName": "reminder.index.html.delete_reminder"
  }
}, 'scrap');
_cat.core.define("reminder.index.html.delete_reminder$$cat", function(thi$) {

  var pkgName = "reminder.index.html.delete_reminder$$cat",
    _argsrefs = arguments,
    _argsnames = "thi$",
    _args = {},
    _ipkg = _cat.core.getVar(pkgName),
    _counter = 0;

  if (_args) {
    _argsnames = _argsnames.split(",");
    _argsnames.forEach(function(arg) {
      _args[arg] = _argsrefs[_counter];
      _counter++;
    });
  }

  /* test content in here */
  _cat.core.clientmanager.delayManager(["_cat.core.ui.setContent({style: 'color:#0080FF', header: 'delete_reminder', desc: 'click($(\"#remindlist li[caption=\\\"Apple iPhone Big Announcement\\\"] a[title=\\\"delete\\\"]\"));',tips: ''});"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.click($(\"#remindlist li[caption=\\\"Apple iPhone Big Announcement\\\"] a[title=\\\"delete\\\"]\"));"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.utils.chai.assert(context);"], {
    'code': ["assert", "ok($('#remindlist li[caption=\"Apple iPhone Big Announcement\"] a[title=\"delete\"]').size()==0,\"delete reminder failed\")\n"].join("."),
    'fail': true,
    scrap: _ipkg.scrap,
    args: _args
  });
});
_cat.core.declare('reminder.index.html.logout$$cat', {
  scrap: {
    "name": ["logout"],
    "embed": ["true"],
    "jqm": ["clickButton(\"#logoutbtn\");"],
    "assert": ["ok($.mobile.activePage.attr(\"id\")==\"login\",\"logout failed\");"],
    "file": "/Users/eli.mordechaihp.com/Documents/cat-project/target/reminder/index.html",
    "scrapinfo": {
      "start": {
        "line": 76,
        "col": 0
      },
      "end": {
        "line": 81,
        "col": 2
      }
    },
    "commentinfo": {
      "start": {
        "line": 75,
        "col": 0
      },
      "end": {
        "line": 82,
        "col": 3
      }
    },
    "single": {
      "name": true,
      "embed": true,
      "jqm": false,
      "assert": false,
      "file": true,
      "scrapinfo": true,
      "commentinfo": true,
      "single": true,
      "singleton": true,
      "arguments": true,
      "context": false,
      "auto": true,
      "injectcode": true,
      "id": true,
      "$type": true,
      "numCommands": true
    },
    "singleton": {
      "name": -1,
      "embed": -1,
      "jqm": -1,
      "assert": -1,
      "file": -1,
      "scrapinfo": -1,
      "commentinfo": -1,
      "single": -1,
      "singleton": -1,
      "arguments": -1,
      "context": 1,
      "auto": -1,
      "injectcode": -1,
      "id": -1,
      "$type": -1,
      "numCommands": -1
    },
    "arguments": ["thi$"],
    "context": ["thi$"],
    "auto": true,
    "injectcode": false,
    "id": "scrap_f96ce60c-bcb8-61e1-4e2e-3cbc315d6c7d",
    "$type": "html",
    "numCommands": 3,
    "pkgName": "reminder.index.html.logout"
  }
}, 'scrap');
_cat.core.define("reminder.index.html.logout$$cat", function(thi$) {

  var pkgName = "reminder.index.html.logout$$cat",
    _argsrefs = arguments,
    _argsnames = "thi$",
    _args = {},
    _ipkg = _cat.core.getVar(pkgName),
    _counter = 0;

  if (_args) {
    _argsnames = _argsnames.split(",");
    _argsnames.forEach(function(arg) {
      _args[arg] = _argsrefs[_counter];
      _counter++;
    });
  }

  /* test content in here */
  _cat.core.clientmanager.delayManager(["_cat.core.ui.setContent({style: 'color:#0080FF', header: 'logout', desc: 'clickButton(\"#logoutbtn\");',tips: ''});"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.core.plugin(\"jqm\").actions.clickButton(\"#logoutbtn\");"], {
    scrap: _ipkg.scrap,
    args: _args
  });
  _cat.core.clientmanager.delayManager(["_cat.utils.chai.assert(context);"], {
    'code': ["assert", "ok($.mobile.activePage.attr(\"id\")==\"login\",\"logout failed\")\n"].join("."),
    'fail': true,
    scrap: _ipkg.scrap,
    args: _args
  });
});